import React from 'react'

const Shop = () => {
  return (
    <div>Shop</div>
  )
}

export default Shop