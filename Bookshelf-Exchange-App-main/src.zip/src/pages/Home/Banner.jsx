import React from 'react'
import BannerCard from '../shared/BannerCard'

export const Banner = () => {
    return (
        <div className=' bg-teal-100  px-4 lg:px-24 flex items-center'>
            <div className='flex flex-col md:flex-row-reverse justify-between items-center gap-12 py-40'>
                {/* right side */}
                <div className='md:w-1/2 h-full'>
                    <BannerCard />
                </div>

                {/* left side */}
                <div className='md:w-1/2 space-y-8 bg-teal-100'>
                    <h1 className='lg:text-6xl text-5xl font-bold text-black mb-5 lg:leading-tight leading-snug'><span className='text-blue-900'>Exchange Your</span> <span className='text-red-700'>SecondHand Books</span> <span className='text-blue-900'>For The Best Prices</span></h1>
                    <p>Welcome to our platform, where sharing meets affordability in the world of books. Here, users can connect to share their beloved reads at economical prices, fostering a community built on a love
                        for literature. Whether you're seeking a thrilling mystery, a heartwarming romance,
                        or a mind-expanding non-fiction, our platform offers a diverse selection to suit every taste and budget. Join us in the joy of reading while also promoting sustainability and accessibility in the literary world. Happy reading!</p>
                    <div>
                        <input type="search" placeholder='Search a book here' className='py-2 px-2 rounded-s-sm' />
                        <button className='bg-blue-700 px-6 py-2 text-white font-medium hover:bg-black transition-all ease-in duration-200'>Search</button>
                    </div>
                </div>
            </div>
        </div>
    )
}
